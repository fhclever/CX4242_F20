print('main')
exec(open('gene_expression_user.py').read())